(function ($) {
	$('.wpb_el_type_dt_gradient_picker .of-slider').each(function () {
		window.The7Options.slider(this);
	});

	$('.wpb_el_type_dt_gradient_picker .grad_ex').each(function () {
		window.The7Options.gradientPicker(this);
	});
})(jQuery);

